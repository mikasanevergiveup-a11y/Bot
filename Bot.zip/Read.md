# Telegram Bot ၄ ခုကို Bot တစ်ခုတည်းအဖြစ် ပေါင်းစပ်ရန် Master Prompt

အောက်ပါ attached ZIP files ထဲရှိ Telegram bot project များကို အပြည့်အဝ စစ်ဆေးပြီး **Bot ၄ ခု၏ commands, features, database logic, admin flow နှင့် user flow အားလုံး မပျောက်ဘဲ Telegram Bot တစ်ခုတည်းအဖြစ် production-ready ပေါင်းစပ်ပေးပါ။**

သတိ Music Bot နှင့် Group Help bot သည် သက်ဖန်တီး တည်ဆောက်ရမည်ဖြစ်သည်။ ကျတော် zip ထဲတွက်ပေးထားသည့် screenshot ထဲ၌ bot ၏ ၊design ကို အတုယူပါ။ bot များအားလုံးအတွက် button များသည် Telegram lastest bot api update မှာ button design အသစ်များ ကိုအသုံးပြုပါ။

## ၁။ အရေးကြီးသော စည်းကမ်းချက်များ


1. အရင်ဆုံး attached ZIP files အားလုံးကို extract လုပ်ပြီး project တစ်ခုချင်းစီ၏ README, source code, database schema, environment variables, handlers, callbacks, commands, scheduled jobs နှင့် deployment configuration များကို audit လုပ်ပါ။
2. မူရင်း bot များထဲရှိ feature တစ်ခုမျှ မပျောက်စေရပါ။ Feature တူညီမှု၊ command တူညီမှု သို့မဟုတ် database table တူညီမှုရှိပါက conflict မဖြစ်အောင် unified design ဖြင့် ပြန်တည်ဆောက်ပါ။
3. လက်ရှိ ZIP ထဲတွင် project ၂ ခုသာရှိပါက အဆိုပါ ၂ ခုကို အရင်ဆုံး အပြည့်အဝ merge လုပ်ပြီး၊ ကျန် Bot ၂ ခု၏ ZIP/source code မရှိသေးပါက မခန့်မှန်းဘဲ `MISSING_SOURCE_BOTS.md` ထဲတွင် လိုအပ်သည့် files, commands နှင့် integration details စာရင်းပြုစုပါ။ Source code မရှိသည့် feature များကို fake implementation မလုပ်ပါနှင့်။
4. မူရင်း project တွင် ရှိပြီးသား framework ကို အလွယ်တကူ မပြောင်းပါနှင့်။ သို့သော် unified bot အတွက် maintainability, reliability နှင့် deployment အကောင်းဆုံးဖြစ်စေရန် လိုအပ်ပါက architecture migration plan နှင့်အတူ ပြောင်းနိုင်သည်။
5. Telegram Bot API best practices၊ idempotency၊ retry၊ rate limit၊ permission check၊ callback security၊ input validation နှင့် error handling အားလုံး ထည့်သွင်းပါ။
6. Secret များဖြစ်သော `BOT_TOKEN`, `DATABASE_URL`, payment information, admin IDs နှင့် webhook secret များကို source code, README, log သို့ မရေးပါနှင့်။ `.env.example` သာ ထည့်ပါ။

---


## ၂။ ပေါင်းစပ်ရမည့် အဓိက Bot Modules

Unified bot ကို module/feature အလိုက် ခွဲထားပါ။ အနည်းဆုံး အောက်ပါ module များပါဝင်ရမည်။

### A. Group Help / Task Management Module

မူရင်း Group Task bot ၏ အောက်ပါ feature များအားလုံးကို ထည့်ပါ။

#### User onboarding

- `/start` command ဖြင့် welcome flow စတင်ရန်
- Channel နှင့် Chat force-join စစ်ဆေးရန်
- Force-join အတွက် inline buttons နှင့် `✅ Check` button ထည့်ရန်
- `/setch <chat_id_or_username> <invite_link>` ဖြင့် channel setting သိမ်းရန်
- `/setc <chat_id_or_username> <invite_link>` ဖြင့် chat setting သိမ်းရန်
- Rules message ကို admin က reply လုပ်ပြီး `/setrules` ဖြင့် သိမ်းရန်
- Rules တွင် `နားလည်သဘောတူလက်ခံပါတယ်` နှင့် `ငြင်းပယ်ပါတယ်` ခလုတ်များ ပါရမည်
- Rules ကို accept လုပ်ပြီးသူများကိုသာ assigned task group link ပို့ရန်
- Reject လုပ်သူများကို task group link မပို့ရန်
- IP/device verification, phone contact, OTP စသည့် မလိုအပ်သော verification flow များ မထည့်ရန်

#### Task Group assignment

- Task Group A, B, C ကို support လုပ်ရန်
- Group တစ်ခုချင်းစီတွင် `/registergroup A`, `/registergroup B`, `/registergroup C` ဖြင့် logical label သတ်မှတ်ရန်
- `/setgp1 <invite_link>` ဖြင့် Task Group A link သိမ်းရန်
- `/setgp2 <invite_link>` ဖြင့် Task Group B link သိမ်းရန်
- `/setgp3 <invite_link>` ဖြင့် Task Group C link သိမ်းရန်
- Verified user များကို round-robin သို့မဟုတ် configured assignment logic ဖြင့် A/B/C group သို့ ခွဲရန်
- Assignment ကို database ထဲတွင် persistent သိမ်းရန်
- User သည် assigned group ထဲဝင်ပြီးနောက် bot က ပို့ထားသည့် group link message ကို အလိုအလျောက် ဖျက်ရန်

#### Task photo review

- Registered Task Group A/B/C ထဲတွင် user က photo တင်ပါက photo ကို review အတွက် Checker Group သို့ ပို့ရန်
- Photo နှင့်အတူ username, Telegram user ID, caption, source group, message ID, submitted time နှင့် assigned group ကို ထည့်ပြရန်
- Source Group A → Checker Topic A, B → B, C → C topic mapping ပြုလုပ်ရန်
- `/setcheckgroup <group_id>` ဖြင့် checker group သတ်မှတ်ရန်
- `/setchecktopic A <topic_id_or_message_link>` ဖြင့် topic သတ်မှတ်ရန်
- `/setchecktopic B <topic_id_or_message_link>` ဖြင့် topic သတ်မှတ်ရန်
- `/setchecktopic C <topic_id_or_message_link>` ဖြင့် topic သတ်မှတ်ရန်
- Topic configuration မရှိပါက checker group main chat သို့ fallback ပို့ရန်
- Checker message တွင် အောက်ပါ buttons ထည့်ရန်:
  - `✓ မှန် — Task လုပ်သူသတ်မှတ်`
  - `× မှား — မသတ်မှတ်`
- Approve ပြီးမှသာ source photo ကို `✅` reaction ပေးပြီး approved task အဖြစ် မှတ်တမ်းတင်ရန်
- Reject ပြီးမှသာ source photo ကို `❌` reaction ပေးပြီး task completion အဖြစ် မတွက်ရန်
- Photo ပို့ရုံဖြင့် approved မဖြစ်စေရ။ Checker ၏ဆုံးဖြတ်ချက်ရပြီးမှသာ database status update လုပ်ရန်
- Review တစ်ခုကို double-click / duplicate callback ဖြင့် နှစ်ကြိမ်မလုပ်နိုင်အောင် transaction နှင့် idempotency သုံးရန်
- Decision ပြီးလျှင် review buttons များကို ဖယ်ရှားပြီး decision, reviewer ID နှင့် reviewed time ပြရန်

#### Task report commands

- `/do` — ယနေ့ approved task လုပ်သူစာရင်း
- `/ndo` — ယနေ့ approved task မရှိသေးသူစာရင်း
- `/reset` — လက်ရှိ group ၏ ယနေ့ task tracking reset
- `/topics` — configured topics ပြရန်
- `/settopic <number> <topic_name>` — source group topic configuration

---

### B. Premium Membership / Payment Verification Module

မူရင်း Smart Hub Premium bot ၏ feature များကို ပေါင်းစပ်ပါ။

#### User commands

- `/start` — premium plan ရှင်းလင်းချက်၊ payment account information နှင့် main menu ပြရန်
- `/profile` — user name, username, Telegram ID, language, member role, premium status နှင့် premium expire time ပြရန်
- User က payment receipt/screenshot ပုံပို့ပါက admin review queue ထဲသို့ ပို့ရန်
- Admin က `Confirm` သို့မဟုတ် `Reject` ဖြင့် စစ်ဆေးနိုင်ရမည်
- Confirm ပြီးပါက သတ်မှတ်ထားသော premium duration အတိုင်း user ကို premium ဖြစ်စေရန်
- လက်ရှိ legacy behavior ဖြစ်သော ၂၄ နာရီ premium ကို default အဖြစ်ထားနိုင်သော်လည်း duration ကို setting ဖြင့် ပြောင်းနိုင်ရမည်
- Reject ပြီးပါက user ကို စနစ်တကျ အသိပေးရန်
- User ၏ premium သက်တမ်းကုန်ဆုံးသောအခါ auto-expire ဖြစ်ရမည်
- Expired premium user များကို free user အဖြစ် သတ်မှတ်ရန်

#### Admin commands

- `/setwave <phone_or_account>` — Wave payment account သိမ်းရန်
- `/setkpay <phone_or_account>` — KPay payment account သိမ်းရန်
- `/user` — total users, premium users, pending receipts နှင့် active users အရေအတွက် ပြရန်
- `/broadcastpreuser <message>` — active premium users သို့သာ broadcast ပို့ရန်
- လိုအပ်ပါက receipt list, pending list, premium revoke, premium extend နှင့် user search admin commands များ ထည့်ရန်

#### Payment safety

- Payment receipt တစ်ခုတည်းကို duplicate submit မဖြစ်အောင် hash/message ID ဖြင့် စစ်ရန်
- Admin confirm/reject action ကို authorized admin များသာ လုပ်နိုင်ရမည်
- Payment receipt, reviewer, decision နှင့် audit time အားလုံး database ထဲသိမ်းရန်
- ငွေပေးချေမှုကို auto-confirm မလုပ်ပါနှင့်။ Admin approval လိုအပ်ရမည်။

---

### C. Music Bot Module

Music bot source code ပါလာပါက အောက်ပါအချက်များကို မပျောက်အောင် audit လုပ်ပြီး merge ပါ။

- မူရင်း music bot ၏ commands အားလုံးကို source code မှ အလိုအလျောက်ဖော်ထုတ်ပြီး command registry ထဲထည့်ရန်
- Search, play, pause, resume, skip, stop, queue, now playing, volume, playlist, download/stream နှင့် related callbacks များရှိပါက အားလုံးထည့်ရန်
- User သည် group/private chat မည်သည့်နေရာတွင် အသုံးပြုနိုင်သည်ကို မူရင်း behavior အတိုင်း ထိန်းသိမ်းရန်
- Voice chat/library/dependency များကို deployment documentation ထဲတွင် တိတိကျကျ ရေးရန်
- Music feature သည် premium-only ဖြစ်ပါက premium middleware ဖြင့် စစ်ရန်၊ free user limitation ရှိပါက setting ဖြင့် ထိန်းရန်
- Bot တစ်ခုတည်း၏ command name conflict မဖြစ်အောင် `/music`, `/play`, `/queue` စသည့် command များကို source behavior နှင့်မူရင်း naming အတိုင်း ထိန်းသိမ်းရန်
- Music queue များကို chat တစ်ခုချင်းစီအလိုက် ခွဲထားရန်
- Queue state နှင့် playback state သည် restart ပြီးနောက် လိုအပ်သည့်အတိုင်း restore သို့မဟုတ် clean shutdown ဖြစ်ရန်

Music bot source code မပါသေးပါက အပေါ်ကအချက်များကို placeholder အဖြစ်သာ ထားပြီး မူရင်း feature မရှိသလို မဖန်တီးပါနှင့်။

---

### D. ကျန်ရှိသော Bot Module

Bot ၄ ခုထဲမှ ကျန် bot ၏ ZIP/source code ပါလာပါက:

1. README နှင့် source code ကိုအရင် audit လုပ်ပါ။
2. Commands, callbacks, scheduled jobs, external APIs, database tables, admin controls နှင့် user flow များကို feature inventory အဖြစ် ထုတ်ပါ။
3. Unified bot ထဲတွင် module သီးခြားအဖြစ် ထည့်ပါ။
4. အခြား module များနှင့် command/database conflict မဖြစ်စေရန် namespace, permission နှင့် transaction boundary သတ်မှတ်ပါ။
5. Source မပါပါက မခန့်မှန်းဘဲ missing information ကို ရှင်းလင်းစွာ ရေးပြပါ။

---

## ၃။ User Database Requirements

Supabase PostgreSQL ကို primary database အဖြစ် သုံးပါ။ Database schema သည် normalized, indexed, migration-friendly ဖြစ်ရမည်။ အနည်းဆုံး အောက်ပါ user information များကို သိမ်းပါ။

- `telegram_id`
- `telegram_name`
- `telegram_username`
- `language`
- `is_premium`
- `premium_until`
- `premium_remaining_hours`
- `assigned_task_group`
- `is_verified`
- `force_join_completed`
- `rules_accepted`
- `created_at`
- `updated_at`
- `last_seen_at`

အနည်းဆုံး အောက်ပါ table များ သို့မဟုတ် equivalent schema ပါရမည်။

- `users`
- `user_settings`
- `bot_settings`
- `group_assignments`
- `registered_task_groups`
- `checker_topics`
- `task_photo_reviews`
- `task_tracking`
- `premium_receipts`
- `premium_transactions`
- `broadcast_logs`
- `admin_audit_logs`
- `music_queues` သို့မဟုတ် music state အတွက် equivalent table
- `poller_checkpoints`

### Transaction နှင့် Poller

- Supabase/PostgreSQL transaction ကို အသုံးပြုပြီး payment confirmation, task approval, premium extension, assignment နှင့် reset operations များကို atomic လုပ်ရန်
- `SELECT ... FOR UPDATE` သို့မဟုတ် equivalent locking ဖြင့် duplicate confirmation နှင့် race condition ကာကွယ်ရန်
- Premium expiry, pending receipt, scheduled cleanup, failed broadcast retry နှင့် stale review စစ်ရန် background poller/job ထည့်ရန်
- Poller သည် duplicate run ဖြစ်လည်း safe ဖြစ်ရမည်။ Lock/checkpoint/lease သုံးရန်
- Database transaction မအောင်မြင်ပါက Telegram message ကို success ဟု မပြောရ။ Retry နှင့် rollback logic ထည့်ရန်
- Connection pool, timeout, retry, reconnect နှင့် graceful shutdown ထည့်ရန်
- Database migration files နှင့် initial schema ကို ထည့်ရန်

---

## ၄။ Admin Authorization နှင့် Permission

- `ADMIN_TELEGRAM_IDS` သို့မဟုတ် database-based admin role ဖြင့် admin command များကို ကန့်သတ်ရန်
- Admin group ID, checker group ID, task group IDs နှင့် configuration chat များကို setting ဖြင့် ထိန်းချုပ်ရန်
- Admin မဟုတ်သူများက admin command သုံးပါက လုံခြုံစွာ reject လုပ်ရန်
- Checker သည် checker group နှင့် သတ်မှတ်ထားသော reviewer role ရှိမှသာ approve/reject လုပ်နိုင်ရမည်
- Bot ကို လိုအပ်သည့် group permission များ မရှိပါက အသုံးပြုသူနှင့် admin ကို ရှင်းလင်းသော error ပြရန်
- Sensitive admin actions အားလုံးကို audit log ထဲတွင် သိမ်းရန်

---

## ၅။ UI/UX Design Requirement

ပေးထားသော screenshot ကို visual reference အဖြစ် အသုံးပြုပါ။ Screenshot ထဲက အောက်ပါ design language ကို unified bot ၏ messages, menus, profile နှင့် status cards တွင် အသုံးပြုပါ။

- Telegram dark theme နှင့် လိုက်ဖက်သော dark navy/charcoal message style
- အကြောင်းအရာများကို အပိုင်းလိုက် ခွဲပြထားသော card-style layout
- Premium feel ရစေရန် blue, purple, green, red accent colors
- Welcome/profile screen တွင် အောက်ပါအချက်များကို table-style ဖြင့် ပြရန်:
  - User ID
  - Username
  - Language
  - Member Role
  - Premium status
  - Premium expire time / remaining hours
- Inline buttons များကို အဓိပ္ပါယ်ရှင်းလင်းစွာ အုပ်စုဖွဲ့ရန်
- `Language`, `Supported`, `Developer`, `Get Started`, `Back to Welcome` စသည့် UI sections များကို မူရင်း screenshot ၏ mood နှင့် layout ကို အခြေခံ၍ ပြန်တည်ဆောက်ရန်
- မြန်မာဘာသာနှင့် English နှစ်ဘာသာ support လုပ်ရန်
- Emoji များကို အလွန်အကျွံ မသုံးဘဲ status နှင့် action ကို နားလည်လွယ်စေရန်သာ အသုံးပြုရန်
- Premium Emoji ပါသော admin-configured messages များကို copy လုပ်ရာတွင် emoji/entity မပျက်စေရန်
- Error, success, pending, expired, rejected, approved state များအတွက် တစ်သမတ်တည်း message template များ ပြုလုပ်ရန်

---

## ၆။ Unified Command Registry

- Command အားလုံးကို module အလိုက် registry တစ်ခုထဲတွင် စီမံရန်
- `/start` command တစ်ခုတည်းအောက်တွင် module-aware welcome menu ပြရန်
- `/help` ထည့်ပြီး user ၏ role/premium status အလိုက် အသုံးပြုခွင့်ရှိသော commands များကို ပြရန်
- Command conflict မဖြစ်စေရန် duplicate handler များကို ပေါင်းစည်းရန်
- Group-only, private-only, admin-only, premium-only command များကို middleware ဖြင့် ခွဲရန်
- Callback data များကို signed/validated ဖြစ်စေရန်။ User တစ်ဦးက အခြား user ၏ callback ကို မနှိပ်နိုင်စေရန် စစ်ရန်
- BotFather command menu ကို user/admin scope အလိုက် configure လုပ်ရန်

---

## ၇။ Deployment Requirements

Production deployment အတွက် အောက်ပါအရာများ ထည့်ပါ။

- `.env.example`
- `README.md` အသစ် — setup, local run, Supabase setup, Telegram permissions, deployment, troubleshooting အားလုံးပါရမည်
- Dockerfile သို့မဟုတ် Render/VPS deployment configuration
- Webhook mode နှင့် polling mode အတွက် ရွေးချယ်နိုင်သော configuration
- Health endpoint (`/healthz` သို့မဟုတ် equivalent)
- Graceful shutdown
- Structured logging
- Error monitoring hooks
- Rate-limit handling
- Telegram webhook secret validation
- Supabase SSL/pooler configuration
- PM2/systemd/Render deployment instructions
- Backup နှင့် migration instructions

Environment variables အနည်းဆုံး:

```env
BOT_TOKEN=
DATABASE_URL=
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
WEBHOOK_BASE_URL=
WEBHOOK_SECRET=
ADMIN_TELEGRAM_IDS=
ADMIN_GROUP_ID=
CHECK_GROUP_ID=
TIMEZONE=Asia/Yangon
PREMIUM_DEFAULT_HOURS=24
POLL_INTERVAL_SECONDS=60
LOG_LEVEL=info
```

Secret များကို commit မလုပ်ရ။ `.env` ကို `.gitignore` ထဲ ထည့်ပါ။

---

## ၈။ Testing Requirements

အောက်ပါ test များကို ရေးပြီး run လုပ်ပါ။

- Unit tests — database helpers, premium expiry, assignment logic, command parsing, callback validation
- Integration tests — `/start`, force join, rules accept/reject, receipt confirm/reject, task photo approve/reject
- Transaction tests — duplicate callback, concurrent approval, rollback
- Permission tests — admin/non-admin, checker/non-checker, premium/free user
- Poller tests — expiry, retry, checkpoint, duplicate poller lock
- Smoke test — health endpoint, webhook route, database connection
- Manual test checklist — BotFather settings, group permission, topics, payment receipt flow, music flow

Test command examples:

```bash
python -m compileall .
pytest -q
# သို့မဟုတ် project သုံးထားသော runtime အလိုက်
npm test
npm run lint
```

Test အားလုံးအောင်မြင်ပြီးမှ final result ပြပါ။

---

## ၉။ Deliverables

အလုပ်ပြီးဆုံးသောအခါ အောက်ပါအရာများ ပေးပါ။

1. Unified bot source code
2. Database schema နှင့် migration files
3. `.env.example`
4. Setup/deployment README
5. Feature inventory — မူရင်း bot တစ်ခုချင်းစီ၏ feature မည်သို့ merge လုပ်ထားသည်
6. Command reference table
7. Admin setup guide
8. Supabase setup guide
9. Test results နှင့် မအောင်မြင်သေးသောအရာများ
10. Missing source/feature list — source code မပါသည့် bot များရှိပါက
11. Known limitations နှင့် နောက်ထပ်လိုအပ်သည့် information

## Final acceptance criteria

- Bot ၄ ခု၏ မူရင်း commands/features များ source ရှိသမျှ အားလုံးအလုပ်လုပ်ရမည်။
- User profile တွင် Telegram name, username, Telegram ID, premium status နှင့် premium expire remaining hours တိတိကျကျ ပြရမည်။
- Payment receipt confirm/reject flow သည် transaction-safe ဖြစ်ရမည်။
- Task photo review သည် checker decision ရပြီးမှသာ approved/rejected ဖြစ်ရမည်။
- Supabase transaction နှင့် poller သည် restart/duplicate run ဖြစ်သော်လည်း data မပျက်စေရ။
- Screenshot design ကို အခြေခံထားသည့် consistent dark premium UI ဖြစ်ရမည်။
- Admin permission, secret protection နှင့် audit logs ပြည့်စုံရမည်။
- Build, tests နှင့် deployment documentation ပြည့်စုံရမည်။
- မရှိသေးသော source code/feature ကို မခန့်မှန်းဘဲ ရှင်းလင်းစွာ report လုပ်ရမည်။

အရင်ဆုံး **project audit နှင့် feature inventory** ကို ပြပါ။ ထို့နောက် architecture plan, database design, implementation, testing နှင့် deployment guide ကို အဆင့်လိုက် ဆောင်ရွက်ပါ။ မေးခွန်းရှိပါက code မစတင်မီ source မရှိသေးသော bot ၂ ခု၏ ZIP files, music bot behavior, premium duration, payment confirmation policy နှင့် deployment target ကို တိတိကျကျ မေးပါ။